let perguntas = {
    izi: [
        { 
            texto: "Izi: Qual é o nome deste pássaro?", 
            respostaCerta: "Red", 
            opcoes: ["Chuck", "Red", "Bomb", "Matilda", "Hal", "Stella"],
            imagem: "Angry Birds - icon.jpg"
        },
        { 
            texto: "Izi: E qual é o nome deste pássaro?", 
            respostaCerta: "Chuck", 
            opcoes: ["Red", "Bomb", "Chuck", "Matilda", "Stella", "Hal"],
            imagem: "Chuck.webp"
        },
        { 
            texto: "Izi: Qual o nome desse?", 
            respostaCerta: "Bomb", 
            opcoes: ["Red", "Chuck", "Stella", "Matilda", "Bomb", "Hal"],
            imagem: "Bomb.svg"
        },
        { 
            texto: "Izi: Qual o nome dessa?", 
            respostaCerta: "Matilda", 
            opcoes: ["Matilda", "Stella", "Red", "Chuck", "Bomb", "Hal"],
            imagem: "Matilda.svg"
        },
        { 
            texto: "Izi: Qual o nome desse bola?", 
            respostaCerta: "Tarêncio", 
            opcoes: ["Stella", "Red", "Matilda", "Chuck", "Bomb", "Tarêncio"],
            imagem: "Terence.webp"
        }
    ],

    medio: [
        {
            texto: "Médio: Em que país a Rovio, empresa criadora de Angry Birds, foi fundada?",
            respostaCerta: "Finlândia",
            opcoes: ["Estados Unidos", "Venezuela", "Brasil", "Finlândia", "Argentina", "Portugal"],
            imagem: "Rovio - Logo.png"
        },
        {
            texto: "Médio: Em que ano Angry Birds foi lançado pela primeira vez?",
            respostaCerta: "2009",
            opcoes: ["2008", "2009", "2010", "2011", "2012", "2013"],
            imagem: "Angry Birds - Era de Ouro.jfif"
        },
        {
            texto: "Médio: Quantos Angry Birds originais estavam no primeiro jogo?",
            respostaCerta: "3",
            opcoes: ["10", "3", "4", "11", "1", "9"],
            imagem: "Birds.avif"
        },
        {
            texto: "Médio: Em qual plataforma Angry Birds se tornou um fenômeno mundial primeiro: iOS ou Android?",
            respostaCerta: "iOS",
            opcoes: ["iOS", "Android"],
            imagem: "Android.gif"
        },
        {
            texto: "Médio: Quantos níveis tinham originalmente o primeiro Angry Birds para iOS?",
            respostaCerta: "63",
            opcoes: ["100", "1", "67", "63", "19", "1000"],
            imagem: "Fases.jpg"
        }
    ],

senior: [
    {
        texto: "Senior: Qual é o nome do pássaro azul que se divide em três quando lançado?",
        respostaCerta: "The Blues (Jay, Jake e Jim)",
        opcoes: [
            "The Blues (Jay, Jake e Jimmy)",
            "The Blues (Jay, Jake e Jim)",
            "The Blues (Jay, John e Jim)",
            "The Blues (Jayden, John e Jimmy)",
            "The Blues (John, Jayden e Jimmy)",
            "The Blues (Jason, Jared e Jimmy)"
        ],
        imagem: "Blue.png"
    },
    {
        texto: "Senior: Qual é o nome do porco verde gigante que aparece no final do primeiro Angry Birds?",
        respostaCerta: "King Pig",
        opcoes: ["King Pig", "Chef Pig", "Mighty Pig", "Grand Pig", "Biggie Pig", "Master Pig"],
        imagem: "King Pig.png"
    },
    {
        texto: "Senior: Qual pássaro foi adicionado primeiro como personagem jogável após Red, Chuck e Bomb?",
        respostaCerta: "Matilda",
        opcoes: ["Matilda", "Hal", "Stella", "Bubbles", "Terence", "Silver"],
        imagem: "Bird - Misterioso.webp"
    },
    {
        texto: "Senior: Qual é a habilidade especial de Hal, o pássaro verde?",
        respostaCerta: "Voar para trás como um bumerangue",
        opcoes: [
            "Explodir ao tocar o alvo",
            "Voar para trás como um bumerangue",
            "Crescer de tamanho",
            "Dividir-se em três",
            "Congelar os blocos",
            "Acelerar em linha reta"
        ],
        imagem: "Hal.webp"
    },
    {
        texto: "Senior: Em Angry Birds 2, quantos tipos diferentes de pássaros jogáveis existem inicialmente?",
        respostaCerta: "9",
        opcoes: ["5", "7", "9", "11", "12", "6"],
        imagem: "Pássaros - Angry Birds 2.webp"
    }
    ]
};

let mensagensFinais = {
    izi: "Tava no izi, até minha vó consegue passar haha!",
    medio: "Você é até bom. Agora quero ver no Senior!",
    senior: "Meus parabéns, eu lhe nomeio Senior. Agora você se tornará um multimilionário!"
};

let niveis = ["izi", "medio", "senior"]; 
let perguntasDoQuiz = [];
let indiceAtual = 0;
let nivelSelecionado = "";

function iniciarQuiz(nivel) {
    nivelSelecionado = nivel;
    perguntasDoQuiz = perguntas[nivel];
    indiceAtual = 0;

    document.getElementById("menu").style.display = "none";
    document.getElementById("quiz").style.display = "block";
    document.getElementById("botoesFinais").innerHTML = "";

    mostrarPergunta();
}

function mostrarPergunta() {
    document.getElementById("resultado").textContent = "";
    document.getElementById("botoesFinais").innerHTML = "";

    let perguntaAtual = perguntasDoQuiz[indiceAtual];
    document.getElementById("pergunta").textContent = perguntaAtual.texto;

    let containerOpcoes = document.getElementById("opcoes");
    containerOpcoes.innerHTML = "";

    if (perguntaAtual.imagem) {
        let img = document.createElement("img");
        img.src = "img/" + perguntaAtual.imagem;
        img.width = 150;
        img.height = 150;
        containerOpcoes.appendChild(img);
    }

    for (let i = 0; i < perguntaAtual.opcoes.length; i++) {
        let botaoOpcao = document.createElement("div");
        botaoOpcao.className = "option";
        botaoOpcao.textContent = perguntaAtual.opcoes[i];
        botaoOpcao.setAttribute("onclick", "verificarResposta('" + perguntaAtual.opcoes[i] + "', '" + perguntaAtual.respostaCerta + "')");
        containerOpcoes.appendChild(botaoOpcao);
    }
}

function verificarResposta(respostaSelecionada, respostaCorreta) {
    if (respostaSelecionada === respostaCorreta) {
        indiceAtual++;
        if (indiceAtual < perguntasDoQuiz.length) {
            mostrarPergunta();
        } else {
            mostrarMensagemFinal();
        }
    } else {
        document.getElementById("resultado").textContent = "Muito Ruim haha. Voltando desde o íncio. . .";
        indiceAtual = 0;
        setTimeout(mostrarPergunta, 1500);
    }
}

function mostrarMensagemFinal() {
    document.getElementById("pergunta").textContent = mensagensFinais[nivelSelecionado];
    document.getElementById("opcoes").innerHTML = "";

    let containerBotoes = document.getElementById("botoesFinais");
    containerBotoes.innerHTML = "";

    let btnVoltar = document.createElement("button");
    btnVoltar.textContent = "<- Voltar";
    btnVoltar.className = "botao-nivel";
    btnVoltar.onclick = () => {
        document.getElementById("quiz").style.display = "none";
        document.getElementById("menu").style.display = "block";
    };
    containerBotoes.appendChild(btnVoltar);

    let nivelIndex = niveis.indexOf(nivelSelecionado);
    if (nivelIndex < niveis.length - 1) {
        let btnProximo = document.createElement("button");
        btnProximo.textContent = "Próximo nível ->";
        btnProximo.className = "botao-nivel";
        btnProximo.onclick = () => iniciarQuiz(niveis[nivelIndex + 1]);
        containerBotoes.appendChild(btnProximo);
    }
}